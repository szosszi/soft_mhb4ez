namespace ZH1_MHB4EZ
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
           #region 1. feladat
            int Faktorialis(int n)
            {
                if (n == 0) return 1;
                return Faktorialis(n - 1) * n;
            }
            DataGridView myGrid = new DataGridView();

            myGrid.Left = 0;
            myGrid.Top = 0;
            myGrid.Width = ClientRectangle.Width / 3;
            myGrid.Height = ClientRectangle.Height;

            List<Sor> list = new List<Sor>();
            for (int i = 1; i < 11; i++)
            {
                Sor akt_sor = new Sor();
                akt_sor.Szam = i;
                akt_sor.Faktorialis = Faktorialis(i);
                list.Add(akt_sor);
            }
            myGrid.DataSource = list;
            Controls.Add(myGrid);

            #endregion

        }
        #region 3. feladat
        private void button1_Click(object sender, EventArgs e)
        {
            for (int sor = 0; sor < 13; sor++)
            {
                for (int oszlop = 0; oszlop < 13; oszlop++)
                {
                    SensitiveButton gombika = new SensitiveButton();
                    gombika.Top = 40 * sor;
                    gombika.Left = ClientRectangle.Width / 3 + 40 * oszlop;
                    Controls.Add(gombika);
                }
            }
        }
        #endregion
    }
}