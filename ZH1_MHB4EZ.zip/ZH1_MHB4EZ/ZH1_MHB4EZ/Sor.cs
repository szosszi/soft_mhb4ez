﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ZH1_MHB4EZ
{
    internal class Sor
    {
        public int Szam { get; set; }

        public int Faktorialis { get; set; }
    }
}
