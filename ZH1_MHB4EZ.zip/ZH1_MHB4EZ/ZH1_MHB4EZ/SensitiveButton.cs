﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ZH1_MHB4EZ
{
    internal class SensitiveButton:Button
    {
        int szam = 0;
        public SensitiveButton()
        {
            this.Width = 40;
            this.Height = 40;
            MouseEnter += SensitiveButton_MouseEnter;
        }

        private void SensitiveButton_MouseEnter(object? sender, EventArgs e)
        {
            
            if (szam < 10) {
                szam++;
                Text = (szam).ToString();
            }
        }
    }
}
