﻿using System;
using System.Collections.Generic;

namespace csillagterkep.Mappa
{
    public partial class ConstellationLine
    {
        public int Star1 { get; set; }
        public int Star2 { get; set; }
    }
}
